package Metapercept1;
import java.util.regex.Pattern;
import java.util.regex.Matcher;
 public class Emailvalidation {
  public static void main(String args[])
  {
	String email = "bhushanhande30@gmail.com";
	
	if (isValidEmail(email))
	{
		System.out.println("Valid Email id");
	}
	else {
		System.out.println("invalid Email id");
	}
}
  private static boolean isValidEmail(String email) {
	  String emailRegex="^[A-Za-z0-9+_.-]+@[A-Za-z0-9.-]+$";
	  Pattern pattern =  Pattern.compile(emailRegex);
	  Matcher matcher=pattern.matcher(email);
	  return matcher.matches();
  }
}
