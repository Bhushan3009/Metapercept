package Metapercept1;

public class B {
 public static int fetchlastdigits(int num) {
	 return num % 10;
 }
}
