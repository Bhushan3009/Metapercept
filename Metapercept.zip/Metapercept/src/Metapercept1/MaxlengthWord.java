package Metapercept1;

public class MaxlengthWord 
{
public static void main(String[] args) 
{
	String s ="dummy text of the printing and typesetting industry";
	String[] words=s.split(" ");
	
	String Maxlengthword=" ";
	int Maxlength=0;
	 
	for(String word : words) 
	{
		word=word.trim();
		if(word.length()>Maxlength) 
		{
		  Maxlength=word.length();
		  Maxlengthword=word;
		}
	}
	System.out.println("Longest word in string is:"+Maxlengthword);
}
}
