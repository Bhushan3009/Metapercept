package Metapercept1;

public class Main {
 public static void main (String[] args) {
	 A input = new A(123,456);
	 int LD1 = B.fetchlastdigits(input.getNum1());
	 int LD2 = B.fetchlastdigits(input.getNum2());
	 int result=C.multiplydigit( LD1 , LD2 );
	 
	 System.out.println("Last digit 1: "+LD1);
	 System.out.println("Last digit 2: "+LD2);
	 System.out.println("Result: "+result);
 }
}
