package Metapercept1;

public class C {
  public static int multiplydigit(int d1,int d2) {
	  return d1 * d2;
  }
}
